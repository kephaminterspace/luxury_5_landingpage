<!--9.footer-->
<div id="footer">
    <div class="wrap">
        <div class="container">
            <!--copyright-->
            <div class="col-lg-6 copyright">
                <p>
                    Copyright 2017 © www.luxurytravelvietnam.com – Tous droits réservés.
                </p>
            </div>
            <!--icon-->
            <div class="col-lg-6 icon">
                <a target="blank" href="https://www.facebook.com/luxurytravelcompany" class="fa fa-facebook-square"></a>
                <a target="blank" href="https://twitter.com/luxurytravelltd" class="fa fa-twitter-square"></a>
                <a target="blank" href="https://www.youtube.com/user/LuxuryTravelVietnam"  class="fa fa-youtube"></a>
            </div>
        </div>
    </div>

</div>