
<div class="col-md-4">
    <a target="blank" href="voyage-de-luxe-et-dauthenticite-au-vietnam.php">
        <img src="img/page2/9.other-tour/tour_escape_hot_time_to vietnam.png"/>
        <p>
            VOYAGE DE LUXE ET D’AUTHENTICITÉ AU VIETNAM
        </p>
    </a>
</div>