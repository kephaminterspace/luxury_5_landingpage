
<div class="col-md-4">
    <a target="blank" href="vietnam-cambodge-hors-des-sentiers-battus.php">
        <img src="img/page2/9.other-tour/tour_best_of_vietnam_cambodia.png"/>
        <p>
            VIETNAM – CAMBODGE: HORS DES SENTIERS BATTUS
        </p>
    </a>
</div>