
<div class="col-md-4">
    <a target="blank" href="le-vietnam-authentique.php">
        <img src="img/other_4.jpg"/>
        <p>
            LE VIETNAM AUTHENTIQUE
        </p>
    </a>
</div>