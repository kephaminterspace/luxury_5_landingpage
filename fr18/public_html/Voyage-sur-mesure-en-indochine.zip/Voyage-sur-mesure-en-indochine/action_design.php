<!--action design-->
<div id="action_design">
    <a href="#form">
        <div class="action_design">
            <div class="row pull-right">
                <div class=" img">
                    <img src="img/page2/3.highlight/3.icon_nav/form.png">
                </div>
                <div id="menu-right">
                    <p style="margin-top:-9px;">
                        Devis sur<BR>mesure!
                    </p>
                </div>

            </div>
        </div>
    </a>
</div>
