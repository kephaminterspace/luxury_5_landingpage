
<div class="col-md-4">
    <a target="blank" href="la-beaute-du-nord-vietnam.php">
        <img src="img/page2/9.other-tour/tour_vietnam_authentic_18_days.png"/>
        <p>
            LA BEAUTÉ DU NORD VIETNAM
        </p>
    </a>
</div>